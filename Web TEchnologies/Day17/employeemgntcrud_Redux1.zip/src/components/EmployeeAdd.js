import {Button} from 'react-bootstrap';
import {Form} from 'react-bootstrap';
import {useState} from 'react';
//import {useHistory} from 'react'
import { useDispatch } from 'react-redux';
import {addemployeearr} from "../redux/actions/EmployeeActions";
const EmployeeAdd=(props)=>{
    const [empob,setempob]=useState({empid:"",ename:"",desg:""});
    const dispatch=useDispatch();
    //const history=useHistory();
    const handlechange=(ev)=>{
        console.log("in handle change");
        const {name,value} =ev.target;
        setempob({...empob,[name]:value})
        
    }

    const addData=(event)=>{
        event.preventDefault(); /////  stops the default refresh action of submit
        if(empob.empid==="" || empob.ename==="" || empob.mobile === ""){
            alert("Pls fill all the details")
            return;
        }
        //props.addEmployee(empob);
        dispatch(addemployeearr(empob))
        setempob({empid:"",name:"",desg:""})
        //history.push("/list");
        props.changeflag(false);

    }

    return(
    <div>
        <Form onSubmit={addData}>
      <Form.Group className="mb-3" >
        <Form.Label>Employee id</Form.Label>
        <Form.Control type="text" placeholder="Enter Id" name="empid" id="empid" 
        value={empob.empid}
        onChange={handlechange}
        />
        
      </Form.Group>

      <Form.Group className="mb-3" >
        <Form.Label>Employee Name</Form.Label>
        <Form.Control type="text" placeholder="enter name" name="ename" id="name"
        value={empob.ename}
        onChange={handlechange}
        />
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Employee Mobile</Form.Label>
        <Form.Control type="text" placeholder="enter mobile" name="mobile" id="mobile"
        value={empob.mobile}
        onChange={handlechange}
        />
      </Form.Group>
      
      <Button variant="primary" type="submit" name="btn" id="btn" >
       Add Employee
      </Button>
    </Form>
    </div>);
}

export default EmployeeAdd;