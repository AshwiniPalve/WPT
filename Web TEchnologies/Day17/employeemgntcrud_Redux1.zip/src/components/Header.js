const Header=()=>{
    return(
        <div style={{background:"blue",color:"white",width:"600px",marginLeft:"300px",borderRadius:"6px"}}>
            <h1>Employee Management system</h1>
        </div>
    )
}

export default Header;