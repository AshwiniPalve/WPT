import { ActionTypes } from "../constants/action-types"
const initialState={
    emparr:[]
}
export const employeearrReducer=(state=initialState,{type,payload})=>{
    console.log("in employeereducer")
    switch(type){
        case ActionTypes.SET_EMPARR:
           return({...state,emparr:payload});
        case ActionTypes.DELETE_EMPARR:

            return({...state,emparr:state.emparr.filter(x=>x.empid!==payload.empid)});
        case ActionTypes.ADD_EMPARR:
            //using axios send to webservice
            //then also add in local array or send get request to web service
            return({...state,emparr:[...state.emparr,{...payload}]});
        default:
            return state;
    }
}


    /* export const selectedEmployee=(state=initialState,{type,payload})=>{
    console.log("in selectedemployeereducer");
    

} */

